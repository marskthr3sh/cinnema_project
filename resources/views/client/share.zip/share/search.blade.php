<div id="overlay-search">
    <form method="get" action="./">
        <input type="text" name="s" placeholder="Search..." autocomplete="off">
        <button type="submit">
            <i class="fa fa-search"></i>
        </button>
    </form>
    <a href="javascript:;" class="close-window"></a>
</div>
