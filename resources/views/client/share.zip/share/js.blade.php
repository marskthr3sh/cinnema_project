<!-- Include jQuery and Scripts -->
<script type="text/javascript" src="/assets_client/js/packages.min.js"></script>
<script type="text/javascript" src="/assets_client/js/scripts.min.js"></script>
<!-- jQuery easing plugin -->
